package com.permmanager.shizuku

import android.content.pm.PackageInfo
import android.content.pm.PackageManager

/**
 * IPermissionService.aidl equivalent — defined in Kotlin as a plain interface.
 * Shizuku runs this in a privileged shell process (UID=2000 / ADB).
 *
 * All calls happen over Binder IPC, so they MUST be lightweight.
 */
interface IShizukuService {
    fun getInstalledPackages(flags: Int): List<PackageInfo>
    fun getPackagePermissions(packageName: String): List<PermissionInfo>
    fun setPermission(packageName: String, permission: String, grant: Boolean): Boolean
    fun revokeAllDangerous(packageName: String): Int   // returns count revoked
    fun destroy()
}

data class PermissionInfo(
    val name: String,
    val label: String,
    val group: String?,
    val protectionLevel: Int,   // PROTECTION_DANGEROUS = 1
    val granted: Boolean,
    val flags: Int
) : java.io.Serializable

val PermissionInfo.isDangerous get() = protectionLevel and 0xF == 1
val PermissionInfo.isGranted   get() = granted
