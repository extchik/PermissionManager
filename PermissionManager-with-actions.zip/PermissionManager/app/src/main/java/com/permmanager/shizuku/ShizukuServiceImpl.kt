package com.permmanager.shizuku

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/**
 * This class runs inside the Shizuku privileged service process (shell UID 2000).
 * It has access to hidden/restricted APIs that normal apps cannot call.
 *
 * Shizuku uses reflection + Binder to proxy calls here from the UI process.
 */
class ShizukuServiceImpl : IShizukuService {

    private val pm: PackageManager by lazy {
        // In Shizuku process we can access the system PackageManager directly
        android.app.ActivityThread.currentApplication().packageManager
    }

    override fun getInstalledPackages(flags: Int): List<PackageInfo> {
        return try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getInstalledPackages(flags)
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun getPackagePermissions(packageName: String): List<PermissionInfo> {
        return try {
            val flags = PackageManager.GET_PERMISSIONS
            val pkgInfo = if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, flags)
            }

            val requestedPerms = pkgInfo.requestedPermissions ?: return emptyList()
            val permFlags = pkgInfo.requestedPermissionsFlags ?: IntArray(requestedPerms.size)

            requestedPerms.mapIndexed { i, permName ->
                try {
                    val pi = pm.getPermissionInfo(permName, 0)
                    val label = pi.loadLabel(pm).toString()
                    val group = pi.group
                    val protection = pi.protectionLevel
                    val granted = (permFlags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                    PermissionInfo(
                        name = permName,
                        label = label,
                        group = group,
                        protectionLevel = protection,
                        granted = granted,
                        flags = permFlags[i]
                    )
                } catch (e: PackageManager.NameNotFoundException) {
                    PermissionInfo(
                        name = permName,
                        label = permName.substringAfterLast('.'),
                        group = null,
                        protectionLevel = 0,
                        granted = false,
                        flags = 0
                    )
                }
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    override fun setPermission(packageName: String, permission: String, grant: Boolean): Boolean {
        return try {
            // Shell has permission to call pm grant/revoke via runtime
            val cmd = if (grant) {
                "pm grant $packageName $permission"
            } else {
                "pm revoke $packageName $permission"
            }
            val process = Runtime.getRuntime().exec(cmd)
            process.waitFor() == 0
        } catch (e: Exception) {
            false
        }
    }

    override fun revokeAllDangerous(packageName: String): Int {
        val perms = getPackagePermissions(packageName)
        var count = 0
        perms.filter { it.isDangerous && it.isGranted }.forEach { perm ->
            if (setPermission(packageName, perm.name, false)) count++
        }
        return count
    }

    override fun destroy() {
        // cleanup — Shizuku will GC this automatically
    }
}
