package com.permmanager.data

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.permmanager.shizuku.ShizukuManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class PermissionRepository(private val context: Context) {

    private val pm get() = context.packageManager

    /**
     * Load all installed packages. Uses Shizuku when available for full access,
     * falls back to standard PM (limited data without Shizuku).
     */
    suspend fun loadApps(): List<AppInfo> = withContext(Dispatchers.IO) {
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_META_DATA

        val packages = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }

        packages.mapNotNull { pkg ->
            try {
                val appName = pkg.applicationInfo?.loadLabel(pm)?.toString() ?: pkg.packageName
                val isSystem = (pkg.applicationInfo?.flags ?: 0) and
                    android.content.pm.ApplicationInfo.FLAG_SYSTEM != 0

                val requestedPerms = pkg.requestedPermissions ?: emptyArray()
                val permFlags = pkg.requestedPermissionsFlags ?: IntArray(requestedPerms.size)

                val permissions = requestedPerms.mapIndexed { i, permName ->
                    try {
                        val pi = pm.getPermissionInfo(permName, 0)
                        val isDangerous = pi.protectionLevel and 0xF == 1
                        val granted = (permFlags[i] and
                            android.content.pm.PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0
                        AppPermission(
                            name = permName,
                            label = pi.loadLabel(pm).toString(),
                            group = pi.group,
                            groupLabel = groupLabel(pi.group),
                            isDangerous = isDangerous,
                            granted = granted
                        )
                    } catch (e: PackageManager.NameNotFoundException) {
                        null
                    }
                }.filterNotNull()

                AppInfo(
                    packageName = pkg.packageName,
                    appName = appName,
                    isSystem = isSystem,
                    targetSdk = pkg.applicationInfo?.targetSdkVersion ?: 0,
                    permissions = permissions
                )
            } catch (e: Exception) {
                null
            }
        }.sortedWith(compareByDescending<AppInfo> { it.dangerousGranted }.thenBy { it.appName })
    }

    /**
     * Grant or revoke a single permission via Shizuku shell.
     * Returns true on success.
     */
    suspend fun setPermission(
        packageName: String,
        permission: String,
        grant: Boolean
    ): Result<Unit> = withContext(Dispatchers.IO) {
        val svc = ShizukuManager.service
            ?: return@withContext Result.failure(Exception("Shizuku недоступний"))

        val ok = svc.setPermission(packageName, permission, grant)
        if (ok) Result.success(Unit)
        else Result.failure(Exception("Не вдалося ${if (grant) "надати" else "відкликати"} дозвіл"))
    }

    /**
     * Revoke all dangerous permissions for an app.
     */
    suspend fun revokeAllDangerous(packageName: String): Result<Int> =
        withContext(Dispatchers.IO) {
            val svc = ShizukuManager.service
                ?: return@withContext Result.failure(Exception("Shizuku недоступний"))
            Result.success(svc.revokeAllDangerous(packageName))
        }
}
