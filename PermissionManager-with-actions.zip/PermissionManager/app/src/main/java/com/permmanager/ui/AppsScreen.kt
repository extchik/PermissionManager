package com.permmanager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.permmanager.data.AppInfo
import com.permmanager.data.RiskLevel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppsScreen(
    onAppClick: (String) -> Unit,
    viewModel: AppsViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            Column(
                Modifier.background(MaterialTheme.colorScheme.surface)
            ) {
                TopAppBar(
                    title = {
                        Column {
                            Text("Менеджер дозволів", fontWeight = FontWeight.Normal)
                            Text(
                                "Android 15 · Privacy Dashboard",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.loadApps() }) {
                            Icon(Icons.Default.Refresh, contentDescription = "Оновити")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )

                // Summary chips
                if (!state.isLoading && state.apps.isNotEmpty()) {
                    SummaryRow(state.apps)
                }

                // Search
                SearchBar(
                    query = state.query,
                    onQueryChange = viewModel::onSearch,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                // Filter tabs
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(FilterTab.entries) { tab ->
                        FilterChip(
                            selected = state.filterTab == tab,
                            onClick = { viewModel.onFilterTab(tab) },
                            label = { Text(tab.label, fontSize = 13.sp) }
                        )
                    }
                }
                HorizontalDivider()
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when {
                state.isLoading -> LoadingScreen()
                state.error != null -> ErrorScreen(state.error!!) { viewModel.loadApps() }
                state.filteredApps.isEmpty() -> EmptyScreen()
                else -> AppsList(state.filteredApps, onAppClick)
            }
        }
    }
}

@Composable
private fun SummaryRow(apps: List<AppInfo>) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        val high   = apps.count { it.riskLevel == RiskLevel.HIGH }
        val medium = apps.count { it.riskLevel == RiskLevel.MEDIUM }
        val safe   = apps.count { it.riskLevel == RiskLevel.LOW }

        SummaryCard("$high",   "Небезпечних", Color(0xFFB3261E), Modifier.weight(1f))
        SummaryCard("$medium", "Помірних",    Color(0xFFE65100), Modifier.weight(1f))
        SummaryCard("$safe",   "Безпечних",   Color(0xFF1B7F3C), Modifier.weight(1f))
        SummaryCard("${apps.size}", "Всього", MaterialTheme.colorScheme.primary, Modifier.weight(1f))
    }
}

@Composable
private fun SummaryCard(value: String, label: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(
            containerColor = color.copy(alpha = 0.1f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            Modifier.padding(vertical = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = color)
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SearchBar(query: String, onQueryChange: (String) -> Unit, modifier: Modifier) {
    OutlinedTextField(
        value = query,
        onValueChange = onQueryChange,
        modifier = modifier.fillMaxWidth(),
        placeholder = { Text("Пошук додатків...") },
        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
        trailingIcon = {
            if (query.isNotEmpty()) {
                IconButton(onClick = { onQueryChange("") }) {
                    Icon(Icons.Default.Clear, contentDescription = "Очистити")
                }
            }
        },
        singleLine = true,
        shape = RoundedCornerShape(28.dp),
        colors = OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceVariant
        )
    )
}

@Composable
private fun AppsList(apps: List<AppInfo>, onAppClick: (String) -> Unit) {
    LazyColumn {
        items(apps, key = { it.packageName }) { app ->
            AppItem(app = app, onClick = { onAppClick(app.packageName) })
            HorizontalDivider(modifier = Modifier.padding(horizontal = 72.dp))
        }
        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun AppItem(app: AppInfo, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // App icon placeholder (colored circle with initial)
        val bgColor = when (app.riskLevel) {
            RiskLevel.HIGH   -> Color(0xFFFDE8E8)
            RiskLevel.MEDIUM -> Color(0xFFFEF0E3)
            RiskLevel.LOW    -> Color(0xFFE6F4EA)
            RiskLevel.SYSTEM -> Color(0xFFF3E5F5)
        }
        Box(
            Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                app.appName.first().uppercase(),
                fontSize = 18.sp,
                fontWeight = FontWeight.Medium,
                color = MaterialTheme.colorScheme.onSurface
            )
        }

        Column(Modifier.weight(1f)) {
            Text(
                app.appName,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                app.packageName,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        val (badgeColor, badgeText) = when {
            app.dangerousGranted >= 4 -> Color(0xFFB3261E) to "${app.dangerousGranted} небезп."
            app.dangerousGranted >= 1 -> Color(0xFFE65100) to "${app.dangerousGranted} дозволів"
            else                      -> Color(0xFF1B7F3C) to "Безпечний"
        }
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = badgeColor.copy(alpha = 0.12f)
        ) {
            Text(
                badgeText,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = badgeColor
            )
        }
    }
}

@Composable
private fun LoadingScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            CircularProgressIndicator()
            Spacer(Modifier.height(16.dp))
            Text("Завантаження додатків...", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ErrorScreen(error: String, onRetry: () -> Unit) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            Text("⚠️", fontSize = 40.sp)
            Spacer(Modifier.height(12.dp))
            Text(error, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
            Spacer(Modifier.height(16.dp))
            Button(onClick = onRetry) { Text("Спробувати знову") }
        }
    }
}

@Composable
private fun EmptyScreen() {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🔍", fontSize = 44.sp)
            Spacer(Modifier.height(12.dp))
            Text("Нічого не знайдено", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
