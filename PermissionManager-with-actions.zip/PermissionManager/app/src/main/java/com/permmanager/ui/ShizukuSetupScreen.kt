package com.permmanager.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.permmanager.shizuku.ShizukuManager

@Composable
fun ShizukuSetupScreen(state: ShizukuManager.State) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("🔐", fontSize = 64.sp)
        Spacer(Modifier.height(24.dp))
        Text(
            "Потрібен Shizuku",
            fontSize = 24.sp,
            fontWeight = FontWeight.Medium
        )
        Spacer(Modifier.height(12.dp))
        Text(
            "Permission Manager використовує Shizuku для безпечного доступу до привілейованих API без root.",
            fontSize = 15.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )

        Spacer(Modifier.height(32.dp))

        // Status card
        val (statusColor, statusIcon, statusText) = when (state) {
            is ShizukuManager.State.Unavailable  -> Triple(Color(0xFFB3261E), "✗", "Shizuku не запущено")
            is ShizukuManager.State.NeedPermission -> Triple(Color(0xFFE65100), "!", "Потрібен дозвіл")
            is ShizukuManager.State.Connecting   -> Triple(Color(0xFF1B6EF3), "↻", "Підключення...")
            is ShizukuManager.State.Ready        -> Triple(Color(0xFF1B7F3C), "✓", "Підключено!")
            is ShizukuManager.State.Error        -> Triple(Color(0xFFB3261E), "✗", "Помилка: ${state.msg}")
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = statusColor.copy(alpha = 0.1f)),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(statusIcon, fontSize = 20.sp, color = statusColor, fontWeight = FontWeight.Bold)
                Text(statusText, color = statusColor, fontWeight = FontWeight.Medium)
            }
        }

        Spacer(Modifier.height(32.dp))

        // Steps
        Text(
            "Як налаштувати Shizuku",
            fontSize = 16.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(Modifier.height(12.dp))

        val steps = listOf(
            "1" to "Встановіть Shizuku з Google Play",
            "2" to "Відкрийте Shizuku та запустіть через ADB або Wireless Debugging",
            "3" to "Поверніться сюди та надайте дозвіл",
            "4" to "Готово — ви маєте повний контроль над дозволами"
        )
        steps.forEach { (num, desc) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    modifier = Modifier.size(28.dp),
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(num, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
                Text(desc, fontSize = 14.sp, lineHeight = 20.sp,
                    color = MaterialTheme.colorScheme.onSurface)
            }
        }

        Spacer(Modifier.height(32.dp))

        if (state is ShizukuManager.State.NeedPermission) {
            Button(
                onClick = { ShizukuManager.requestPermission() },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Надати дозвіл Shizuku", fontSize = 16.sp)
            }
        }

        if (state is ShizukuManager.State.Unavailable || state is ShizukuManager.State.Error) {
            OutlinedButton(
                onClick = { /* open Play Store */ },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) {
                Text("Відкрити Google Play", fontSize = 16.sp)
            }
        }
    }
}
