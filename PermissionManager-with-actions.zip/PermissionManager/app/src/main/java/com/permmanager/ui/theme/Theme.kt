package com.permmanager.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary           = Color(0xFF1B6EF3),
    onPrimary         = Color.White,
    primaryContainer  = Color(0xFFD8E6FD),
    onPrimaryContainer= Color(0xFF001849),
    secondary         = Color(0xFF535F70),
    surface           = Color(0xFFF8F9FF),
    surfaceVariant    = Color(0xFFE2E5F0),
    background        = Color(0xFFF8F9FF),
    error             = Color(0xFFB3261E),
    onSurfaceVariant  = Color(0xFF42464F),
)

private val DarkColorScheme = darkColorScheme(
    primary           = Color(0xFFADC6FF),
    onPrimary         = Color(0xFF002E69),
    primaryContainer  = Color(0xFF00439C),
    surface           = Color(0xFF1A1C22),
    surfaceVariant    = Color(0xFF42464F),
    background        = Color(0xFF1A1C22),
    error             = Color(0xFFF2B8B5),
)

@Composable
fun PermissionManagerTheme(
    darkTheme: Boolean = false,
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colors,
        typography  = Typography(),
        content     = content
    )
}
