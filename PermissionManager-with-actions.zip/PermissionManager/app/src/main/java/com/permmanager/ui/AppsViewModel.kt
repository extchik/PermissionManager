package com.permmanager.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.permmanager.data.AppInfo
import com.permmanager.data.PermissionRepository
import com.permmanager.data.RiskLevel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AppsUiState(
    val isLoading: Boolean = true,
    val apps: List<AppInfo> = emptyList(),
    val filteredApps: List<AppInfo> = emptyList(),
    val query: String = "",
    val filterTab: FilterTab = FilterTab.ALL,
    val error: String? = null
)

enum class FilterTab(val label: String) {
    ALL("Всі"),
    DANGEROUS("Небезпечні"),
    SYSTEM("Системні"),
    USER("Користувацькі")
}

class AppsViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = PermissionRepository(application)

    private val _state = MutableStateFlow(AppsUiState())
    val state: StateFlow<AppsUiState> = _state.asStateFlow()

    init { loadApps() }

    fun loadApps() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, error = null) }
            try {
                val apps = repo.loadApps()
                _state.update { s ->
                    s.copy(isLoading = false, apps = apps,
                        filteredApps = applyFilter(apps, s.query, s.filterTab))
                }
            } catch (e: Exception) {
                _state.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    fun onSearch(query: String) {
        _state.update { s ->
            s.copy(query = query, filteredApps = applyFilter(s.apps, query, s.filterTab))
        }
    }

    fun onFilterTab(tab: FilterTab) {
        _state.update { s ->
            s.copy(filterTab = tab, filteredApps = applyFilter(s.apps, s.query, tab))
        }
    }

    fun setPermission(packageName: String, permission: String, grant: Boolean) {
        viewModelScope.launch {
            repo.setPermission(packageName, permission, grant)
                .onSuccess { loadApps() }
        }
    }

    fun revokeAll(packageName: String) {
        viewModelScope.launch {
            repo.revokeAllDangerous(packageName).onSuccess { loadApps() }
        }
    }

    private fun applyFilter(apps: List<AppInfo>, query: String, tab: FilterTab): List<AppInfo> {
        return apps.filter { app ->
            val matchesQuery = query.isBlank() ||
                app.appName.contains(query, ignoreCase = true) ||
                app.packageName.contains(query, ignoreCase = true)
            val matchesTab = when (tab) {
                FilterTab.ALL -> true
                FilterTab.DANGEROUS -> app.riskLevel == RiskLevel.HIGH
                FilterTab.SYSTEM -> app.isSystem
                FilterTab.USER -> !app.isSystem
            }
            matchesQuery && matchesTab
        }
    }
}
