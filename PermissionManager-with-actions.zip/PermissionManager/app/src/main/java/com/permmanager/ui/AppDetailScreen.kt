package com.permmanager.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.permmanager.data.AppPermission
import com.permmanager.data.AppInfo
import com.permmanager.data.groupIcon
import com.permmanager.data.groupLabel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppDetailScreen(
    packageName: String,
    onBack: () -> Unit,
    viewModel: AppsViewModel = viewModel()
) {
    val state by viewModel.state.collectAsStateWithLifecycle()
    val app = state.apps.find { it.packageName == packageName }

    var showRevokeDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    if (app != null) {
                        Column {
                            Text(app.appName, fontWeight = FontWeight.Normal)
                            Text(
                                app.packageName,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else Text("Деталі")
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Назад")
                    }
                },
                actions = {
                    if (app != null) {
                        IconButton(onClick = { showRevokeDialog = true }) {
                            Icon(
                                Icons.Default.DeleteSweep,
                                contentDescription = "Відкликати всі",
                                tint = MaterialTheme.colorScheme.error
                            )
                        }
                    }
                }
            )
        },
        bottomBar = {
            if (app != null) {
                Surface(shadowElevation = 4.dp) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showRevokeDialog = true },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = MaterialTheme.colorScheme.error
                            ),
                            border = ButtonDefaults.outlinedButtonBorder.copy()
                        ) {
                            Text("Скасувати всі")
                        }
                        Button(
                            onClick = {
                                app.permissions.filter { it.isDangerous && !it.granted }.forEach { p ->
                                    viewModel.setPermission(packageName, p.name, false)
                                }
                                // Grant only safe ones - just reload
                                viewModel.loadApps()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Безпечний режим")
                        }
                    }
                }
            }
        }
    ) { padding ->
        if (app == null) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
            return@Scaffold
        }

        val dangerous = app.permissions.filter { it.isDangerous }
        val normal    = app.permissions.filter { !it.isDangerous }

        LazyColumn(Modifier.padding(padding).padding(horizontal = 16.dp)) {
            // Stats row
            item {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatChip("${app.dangerousGranted}", "небезпечних", Color(0xFFB3261E), Modifier.weight(1f))
                    StatChip("${normal.size}", "звичайних",   Color(0xFF1B7F3C), Modifier.weight(1f))
                    StatChip("${app.permissions.size}", "всього", MaterialTheme.colorScheme.primary, Modifier.weight(1f))
                }
                Spacer(Modifier.height(12.dp))
            }

            // Dangerous permissions section
            if (dangerous.isNotEmpty()) {
                item {
                    SectionHeader("⚠️ Небезпечні дозволи", Color(0xFFB3261E))
                }
                items(dangerous, key = { it.name }) { perm ->
                    PermissionRow(
                        perm = perm,
                        onToggle = { viewModel.setPermission(packageName, perm.name, it) }
                    )
                }
                item { Spacer(Modifier.height(8.dp)) }
            }

            // Normal permissions section
            if (normal.isNotEmpty()) {
                item {
                    SectionHeader("🔵 Звичайні дозволи", MaterialTheme.colorScheme.primary)
                }
                items(normal.take(30), key = { it.name }) { perm ->
                    PermissionRow(perm = perm, onToggle = null)
                }
                if (normal.size > 30) {
                    item {
                        Text(
                            "+ ще ${normal.size - 30} прихованих системних дозволів",
                            Modifier.padding(12.dp),
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(100.dp)) }
        }
    }

    // Revoke All dialog
    if (showRevokeDialog && app != null) {
        AlertDialog(
            onDismissRequest = { showRevokeDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = MaterialTheme.colorScheme.error) },
            title = { Text("Скасувати всі дозволи?") },
            text = { Text("Всі небезпечні дозволи для «${app.appName}» будуть відкликані. Деякі функції можуть перестати працювати.") },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.revokeAll(packageName)
                        showRevokeDialog = false
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) { Text("Скасувати всі") }
            },
            dismissButton = {
                TextButton(onClick = { showRevokeDialog = false }) { Text("Відміна") }
            }
        )
    }
}

@Composable
private fun StatChip(value: String, label: String, color: Color, modifier: Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = color)
            Text(label, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionHeader(title: String, color: Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            color = color,
            letterSpacing = 0.8.sp
        )
        Spacer(Modifier.width(8.dp))
        HorizontalDivider(Modifier.weight(1f), color = color.copy(alpha = 0.2f))
    }
}

@Composable
private fun PermissionRow(perm: AppPermission, onToggle: ((Boolean) -> Unit)?) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
        ),
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(groupIcon(perm.group), fontSize = 20.sp, modifier = Modifier.width(26.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    perm.label.ifBlank { perm.name.substringAfterLast('.') },
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1
                )
                Text(
                    perm.groupLabel,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            if (onToggle != null) {
                Switch(
                    checked = perm.granted,
                    onCheckedChange = onToggle,
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.White,
                        checkedTrackColor = MaterialTheme.colorScheme.primary
                    )
                )
            } else {
                Text(
                    if (perm.granted) "✓" else "—",
                    fontSize = 14.sp,
                    color = if (perm.granted) Color(0xFF1B7F3C) else MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
