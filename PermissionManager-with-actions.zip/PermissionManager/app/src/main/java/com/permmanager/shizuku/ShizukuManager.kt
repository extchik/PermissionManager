package com.permmanager.shizuku

import android.content.ComponentName
import android.content.ServiceConnection
import android.os.IBinder
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import rikka.shizuku.Shizuku

private const val TAG = "ShizukuManager"
private const val SHIZUKU_REQUEST_CODE = 1001

/**
 * Singleton that manages the Shizuku binder connection lifecycle.
 *
 * Usage:
 *   ShizukuManager.init()
 *   if (ShizukuManager.isReady) { ShizukuManager.service?.getInstalledPackages(...) }
 */
object ShizukuManager {

    sealed class State {
        object Unavailable : State()      // Shizuku not installed / not running
        object NeedPermission : State()   // installed but not authorized yet
        object Connecting : State()       // binder bind in progress
        object Ready : State()            // fully operational
        data class Error(val msg: String) : State()
    }

    private val _state = MutableStateFlow<State>(State.Unavailable)
    val state: StateFlow<State> = _state

    val isReady get() = _state.value is State.Ready

    private var _service: IShizukuService? = null
    val service: IShizukuService? get() = _service

    // -------- Shizuku lifecycle listeners --------

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        checkAndRequestPermission()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        _service = null
        _state.value = State.Unavailable
    }

    private val permissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                if (grantResult == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    bindService()
                } else {
                    _state.value = State.NeedPermission
                }
            }
        }

    // -------- ServiceConnection --------

    private val serviceArgs = Shizuku.UserServiceArgs(
        ComponentName("com.permmanager", ShizukuServiceImpl::class.java.name)
    )
        .daemon(false)
        .processNameSuffix("service")
        .debuggable(false)
        .version(1)

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            if (binder != null && binder.pingBinder()) {
                // Wrap raw binder — ShizukuServiceImpl implements IShizukuService directly
                _service = ShizukuServiceImpl()   // in-process for now; replace with Binder proxy if needed
                _state.value = State.Ready
                Log.d(TAG, "Shizuku service connected")
            } else {
                _state.value = State.Error("Binder is dead on connect")
            }
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            _service = null
            _state.value = State.Unavailable
            Log.d(TAG, "Shizuku service disconnected")
        }
    }

    // -------- Public API --------

    fun init() {
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
        Shizuku.addBinderDeadListener(binderDeadListener)
        Shizuku.addRequestPermissionResultListener(permissionResultListener)
    }

    fun release() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener)
        Shizuku.removeBinderDeadListener(binderDeadListener)
        Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        try { Shizuku.unbindUserService(serviceArgs, connection, true) } catch (_: Exception) {}
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
        } catch (e: Exception) {
            _state.value = State.Error(e.message ?: "Cannot request permission")
        }
    }

    // -------- Private --------

    private fun checkAndRequestPermission() {
        if (Shizuku.isPreV11()) {
            _state.value = State.Error("Shizuku version too old (need v11+)")
            return
        }
        try {
            when {
                Shizuku.checkSelfPermission() == android.content.pm.PackageManager.PERMISSION_GRANTED -> bindService()
                Shizuku.shouldShowRequestPermissionRationale() -> _state.value = State.NeedPermission
                else -> _state.value = State.NeedPermission
            }
        } catch (e: Exception) {
            _state.value = State.Error(e.message ?: "Unknown error")
        }
    }

    private fun bindService() {
        _state.value = State.Connecting
        try {
            Shizuku.bindUserService(serviceArgs, connection)
        } catch (e: Exception) {
            _state.value = State.Error(e.message ?: "Bind failed")
        }
    }
}
