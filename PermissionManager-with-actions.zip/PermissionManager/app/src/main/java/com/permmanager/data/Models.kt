package com.permmanager.data

data class AppInfo(
    val packageName: String,
    val appName: String,
    val isSystem: Boolean,
    val targetSdk: Int,
    val permissions: List<AppPermission> = emptyList()
) {
    val dangerousGranted get() = permissions.count { it.isDangerous && it.granted }
    val dangerousTotal   get() = permissions.count { it.isDangerous }
    val riskLevel get() = when {
        dangerousGranted >= 4 -> RiskLevel.HIGH
        dangerousGranted >= 2 -> RiskLevel.MEDIUM
        else                  -> RiskLevel.LOW
    }
}

data class AppPermission(
    val name: String,
    val label: String,
    val group: String?,
    val groupLabel: String,
    val isDangerous: Boolean,
    val granted: Boolean
)

enum class RiskLevel { HIGH, MEDIUM, LOW, SYSTEM }

data class PermissionGroup(
    val name: String,
    val label: String,
    val icon: String,
    val apps: List<Pair<AppInfo, AppPermission>>
)

// Well-known dangerous permission groups with UI metadata
val KNOWN_GROUPS = mapOf(
    "android.permission-group.LOCATION"     to Triple("📍", "Розташування",   RiskLevel.HIGH),
    "android.permission-group.CAMERA"       to Triple("📷", "Камера",         RiskLevel.HIGH),
    "android.permission-group.MICROPHONE"   to Triple("🎙️", "Мікрофон",      RiskLevel.HIGH),
    "android.permission-group.CONTACTS"     to Triple("👥", "Контакти",       RiskLevel.MEDIUM),
    "android.permission-group.STORAGE"      to Triple("💾", "Сховище",        RiskLevel.MEDIUM),
    "android.permission-group.PHONE"        to Triple("📞", "Телефон",        RiskLevel.MEDIUM),
    "android.permission-group.SMS"          to Triple("💬", "SMS",            RiskLevel.HIGH),
    "android.permission-group.CALENDAR"     to Triple("📅", "Календар",       RiskLevel.LOW),
    "android.permission-group.SENSORS"      to Triple("❤️", "Датчики",        RiskLevel.HIGH),
    "android.permission-group.CALL_LOG"     to Triple("📋", "Журнал дзвінків",RiskLevel.HIGH),
    "android.permission-group.NOTIFICATIONS"to Triple("🔔", "Сповіщення",     RiskLevel.LOW),
    "android.permission-group.ACTIVITY_RECOGNITION" to Triple("🏃", "Активність", RiskLevel.MEDIUM),
)

fun groupIcon(group: String?)  = KNOWN_GROUPS[group]?.first  ?: "🔐"
fun groupLabel(group: String?) = KNOWN_GROUPS[group]?.second ?: group?.substringAfterLast('.') ?: "Інше"
