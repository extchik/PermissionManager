package com.permmanager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.*
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.permmanager.shizuku.ShizukuManager
import com.permmanager.ui.AppDetailScreen
import com.permmanager.ui.AppsScreen
import com.permmanager.ui.ShizukuSetupScreen
import com.permmanager.ui.theme.PermissionManagerTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ShizukuManager.init()

        setContent {
            PermissionManagerTheme {
                val shizukuState by ShizukuManager.state.collectAsStateWithLifecycle()
                val navController = rememberNavController()

                if (shizukuState !is ShizukuManager.State.Ready) {
                    ShizukuSetupScreen(shizukuState)
                } else {
                    NavHost(navController = navController, startDestination = "apps") {
                        composable("apps") {
                            AppsScreen(
                                onAppClick = { pkg ->
                                    navController.navigate("detail/${pkg}")
                                }
                            )
                        }
                        composable("detail/{packageName}") { backStack ->
                            val pkg = backStack.arguments?.getString("packageName") ?: return@composable
                            AppDetailScreen(
                                packageName = pkg,
                                onBack = { navController.popBackStack() }
                            )
                        }
                    }
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuManager.release()
    }
}
