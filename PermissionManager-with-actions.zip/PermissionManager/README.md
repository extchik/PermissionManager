# Permission Manager — Android 15 + Shizuku

Повноцінний менеджер дозволів для Android 15 з підтримкою Shizuku (без root).

## Що вміє

- 📋 Перегляд **всіх** встановлених додатків та їхніх дозволів
- 🔴 Класифікація за рівнем ризику (небезпечні / помірні / безпечні)
- 🔁 **Вмикання/вимикання** кожного дозволу одним перемикачем
- 🧹 «Скасувати всі» — відкликати всі небезпечні дозволи одним натисканням
- 🛡️ «Безпечний режим» — залишити лише безпечні дозволи
- 🔍 Пошук та фільтрація за типом
- Shizuku onboarding з покроковими інструкціями

## Технології

- **Kotlin** + **Jetpack Compose** (Material 3)
- **Shizuku API v13** (ADB-рівень привілеїв, без root)
- Navigation Compose, ViewModel, StateFlow

---

## Як зібрати APK (5 хвилин)

### Потрібно
- [Android Studio Ladybug](https://developer.android.com/studio) або новіший
- JDK 17+ (вбудований в Android Studio)
- Android SDK 35

### Кроки

1. **Розпакуйте** архів `PermissionManager.zip`

2. **Відкрийте** папку `PermissionManager` в Android Studio
   (`File → Open → виберіть папку`)

3. **Зачекайте** поки Gradle синхронізується (~2 хв при першому запуску)

4. **Зберіть APK:**
   - У меню: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
   - Або в терміналі:
     ```bash
     ./gradlew assembleDebug
     ```

5. **APK знаходиться за адресою:**
   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

6. **Встановіть** на телефон:
   ```bash
   adb install app/build/outputs/apk/debug/app-debug.apk
   ```

---

## Налаштування Shizuku

Після встановлення APK:

1. Встановіть [Shizuku](https://play.google.com/store/apps/details?id=moe.shizuku.privileged.api) з Google Play
2. Відкрийте Shizuku → **«Wireless Debugging»** (Android 11+):
   - Налаштування → Параметри розробника → Бездротове налагодження → Увімкнути
   - У Shizuku: «Запустити через Wireless Debugging»
3. **Або через ADB** (підключіть USB):
   ```bash
   adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh
   ```
4. Відкрийте Permission Manager → натисніть **«Надати дозвіл»**

---

## Структура проєкту

```
app/src/main/java/com/permmanager/
├── MainActivity.kt              — точка входу, навігація
├── shizuku/
│   ├── IShizukuService.kt       — інтерфейс привілейованого сервісу
│   ├── ShizukuServiceImpl.kt    — реалізація (pm grant/revoke)
│   └── ShizukuManager.kt       — lifecycle, binding, стан
├── data/
│   ├── Models.kt                — AppInfo, AppPermission, RiskLevel
│   └── PermissionRepository.kt — доступ до PackageManager
└── ui/
    ├── AppsScreen.kt            — головний список
    ├── AppDetailScreen.kt       — деталі + перемикачі
    ├── ShizukuSetupScreen.kt    — onboarding
    ├── AppsViewModel.kt         — логіка UI
    └── theme/Theme.kt           — Material 3 кольори
```

---

## Важливо

- `minSdk = 29` (Android 10+), `targetSdk = 35` (Android 15)
- Для зміни дозволів **обов'язково** потрібен активний Shizuku
- Без Shizuku додаток показує дозволи у режимі **тільки читання**
- Системні дозволи (protection level = signature) змінити неможливо навіть через Shizuku
